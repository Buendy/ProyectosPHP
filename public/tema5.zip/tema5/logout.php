<?php session_start() ?>

<?php session_destroy() ?>

<h1>Acabas de salir de la sesión</h1>
<br>
<a href="inicio.php">Regresar a la página principal</a>
